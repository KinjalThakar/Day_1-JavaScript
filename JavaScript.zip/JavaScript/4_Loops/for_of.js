const cities = ["New York", "Tokiyo", "Delhi"];
for (C of cities) {
  document.write("<br/>"+C);
}